/*Enunciado:
  fazer uma programa em java que mostre o seu nome completo, o nome do time de futebol de sua preferência e o bairro onde
  você mora*/
public class exercicio3 {

	public static void main(String[] args) {
		String nome, time_futebol, bairro;
		
		nome = "Giordano Henrique Silveira";
		time_futebol = "Corinthians";
		bairro = "Centro";
		
		System.out.println("Meu nome é " + nome + ", torço para o " + time_futebol + " e moro no " + bairro + " de Quatro Barras");
		

	}

}
