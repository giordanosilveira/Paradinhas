/*Enunciado:
 * fazer um programa em java que calcule e imprima a tabuada de 6. */
public class exercicio1 {

	public static void main(String[] args) {
		
		int i;
		for (i = 0; i < 10; i++) {
			System.out.println(6 * (i + 1));
		}

	}

}
