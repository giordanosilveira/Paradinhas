
public class Exercicio6 {

	public static void main(String[] args) {
		

	}

}
